<?php
if (!defined('ABSPATH')) { exit; }
function lld_checkout_version_warnings($stripe_version, $woo_version) {
    $in_range = function ($version, $minimum, $maximum) {
        return is_string($version) && preg_match('/^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)$/D', $version)
            && version_compare($version, $minimum, '>=') && version_compare($version, $maximum, '<');
    };
    // Reviewed releases inform administrators only. A release number alone must
    // never disable purchases; required APIs and payment settings decide readiness.
    $reviewed = array(
        'stripe_version_unreviewed' => $in_range($stripe_version, '11.0.0', '11.2.0'),
        'woocommerce_version_unreviewed' => $in_range($woo_version, '11.1.2', '11.4.0') || $woo_version === '11.3.0-rc.2',
    );
    return array_keys(array_filter($reviewed, function ($value) { return !$value; }));
}
function lld_checkout_has_methods($target, $methods) {
    if (!is_object($target) && (!is_string($target) || !class_exists($target))) return false;
    foreach ($methods as $method => $arguments) {
        if (!method_exists($target, $method)) return false;
        $reflection = new ReflectionMethod($target, $method);
        if (!$reflection->isPublic() || $reflection->getNumberOfRequiredParameters() > $arguments) return false;
    }
    return true;
}
function lld_checkout_order_helper() {
    return is_callable(array('WC_Stripe_Order_Helper', 'get_instance')) ? WC_Stripe_Order_Helper::get_instance() : null;
}
function lld_checkout_capability_checks($gateway, $countries) {
    return array(
        'stripe_payment_api' => lld_checkout_has_methods($gateway, array('process_payment' => 1, 'verify_intent_after_checkout' => 1)),
        'stripe_order_api' => lld_checkout_has_methods(lld_checkout_order_helper(), array('update_stripe_upe_redirect_processed' => 2, 'delete_stripe_upe_waiting_for_redirect' => 1)),
        'woocommerce_store_api' => lld_checkout_has_methods('Automattic\\WooCommerce\\StoreApi\\Routes\\V1\\Checkout', array('get_response' => 1)),
        'woocommerce_order_api' => function_exists('wc_get_order') && function_exists('wc_load_cart')
            && lld_checkout_has_methods('WC_Order', array('is_paid' => 0, 'get_date_paid' => 0, 'get_transaction_id' => 0, 'is_download_permitted' => 0, 'get_downloadable_items' => 0, 'get_meta' => 1, 'update_meta_data' => 2, 'set_customer_id' => 1, 'save' => 0)),
        'billing_api' => lld_checkout_has_methods($countries, array('get_allowed_countries' => 0, 'get_states' => 0, 'get_address_fields' => 2)),
    );
}
function lld_configuration() {
    $settings = get_option('woocommerce_stripe_settings', array());
    $stripe = is_callable(array('WC_Stripe', 'get_instance')) ? WC_Stripe::get_instance() : null;
    $gateway = is_callable(array($stripe, 'get_main_stripe_gateway')) ? $stripe->get_main_stripe_gateway() : null;
    $woo = function_exists('WC') ? WC() : null;
    $countries = $woo->countries ?? null;
    $upe = $gateway instanceof WC_Stripe_UPE_Payment_Gateway;
    $card = $upe && isset($gateway->payment_methods['card']) ? $gateway->payment_methods['card'] : null;
    $version = defined('WC_STRIPE_VERSION') ? WC_STRIPE_VERSION : '';
    $woo_version = defined('WC_VERSION') ? WC_VERSION : '';
    $test = ($settings['testmode'] ?? '') === 'yes';
    $key = $settings[$test ? 'test_publishable_key' : 'publishable_key'] ?? '';
    $secret = $settings[$test ? 'test_secret_key' : 'secret_key'] ?? '';
    // Select the same mode and keys as the official gateway. Never fall back to
    // test credentials when live mode is selected, or expose a secret key.
    $checks = array_merge(lld_checkout_capability_checks($gateway, $countries), array(
        'stripe_gateway' => $upe,
        'stripe_mode' => in_array($settings['testmode'] ?? '', array('yes', 'no'), true) && $upe && ($gateway->testmode ?? null) === $test,
        'card_payments' => lld_checkout_has_methods($card, array('is_enabled' => 0)) && $card->is_enabled(),
        'guest_checkout' => get_option('woocommerce_enable_guest_checkout') === 'yes',
        'stripe_enabled' => ($settings['enabled'] ?? '') === 'yes',
        'automatic_capture' => ($settings['capture'] ?? 'yes') === 'yes',
        'publishable_key' => is_string($key) && preg_match($test ? '/^pk_test_[A-Za-z0-9]+$/D' : '/^pk_live_[A-Za-z0-9]+$/D', $key) && $upe && $key === ($gateway->publishable_key ?? null),
        'secret_key' => is_string($secret) && preg_match($test ? '/^(?:sk|rk)_test_[A-Za-z0-9]+$/D' : '/^(?:sk|rk)_live_[A-Za-z0-9]+$/D', $secret) && $upe && $secret === ($gateway->secret_key ?? null),
    ));
    $issues = array_keys(array_filter($checks, function ($passed) { return !$passed; }));
    $compatible = !$issues;
    if (get_option('lld_checkout_enabled') !== '1') $issues[] = 'headless_checkout_disabled';
    $billing_fields = array();
    if ($checks['billing_api']) {
        foreach ($countries->get_allowed_countries() as $country => $name) {
            foreach ($countries->get_address_fields($country, 'billing_') as $field_key => $field) {
                $billing_fields[$country][substr($field_key, 8)] = array(
                    'required' => !empty($field['required']) && empty($field['hidden']),
                    'hidden' => !empty($field['hidden']),
                );
            }
        }
    }
    return array(
        'gatewayVersion' => $version, 'woocommerceVersion' => $woo_version, 'testMode' => $test,
        'enabled' => $compatible && get_option('lld_checkout_enabled') === '1',
        'configurationIssues' => $issues,
        'compatibilityWarnings' => lld_checkout_version_warnings($version, $woo_version),
        'publishableKey' => $compatible ? $key : null,
        'countries' => $checks['billing_api'] ? $countries->get_allowed_countries() : array(),
        'states' => $checks['billing_api'] ? $countries->get_states() : array(),
        'billingFields' => $billing_fields,
    );
}
// Only authenticated integration checkout requests receive our correlation and deduplication.
// Ordinary WooCommerce checkout and the gateway's Stripe webhooks are left in place.
add_filter('rest_pre_dispatch', function ($result, $server, $request) {
    if ($result !== null || $request->get_route() !== '/wc/store/v1/checkout' || $request->get_method() !== 'POST' || !$request->get_header('x-lld-signature')) return $result;
    $auth = lld_authenticate_bridge($request);
    if (is_wp_error($auth)) return $auth;
    if (!lld_configuration()['enabled']) return lld_error('React checkout is not enabled for this gateway configuration.', 503);
    if (!$request->get_header('cart-token')) return lld_error('Cart session required.', 403);
    $customer_id = 0;
    $account_token = $request->get_param('_lld_account');
    if ($account_token !== null) {
        $customer = lld_account_user($account_token);
        if (is_wp_error($customer)) return $customer;
        $customer_id = $customer->ID;
    }
    $identity = lld_request_identity($request);
    $identity['customer_id'] = $customer_id;
    $hash = hash('sha256', $request->get_body());
    $existing = lld_record($identity['key']);
    if ($existing) {
        if (($existing['hash'] ?? '') !== $hash) return lld_error('This checkout attempt has different details.', 409);
        if (isset($existing['response'])) return lld_response($existing['response'], $existing['status']);
        return lld_error('This checkout is already processing. Check the order status before trying again.', 409);
    }
    if (!lld_insert($identity['lock'], 'lock', array('attempt' => $identity['attempt']))) return lld_error('A previous checkout is still processing. Check its order status.', 409);
    if (!lld_insert($identity['key'], 'attempt', array('hash' => $hash, 'order' => 0, 'session' => $identity['session'], 'payment_started' => false))) return lld_error('Checkout is already processing.', 409);
    $GLOBALS['lld_checkout_context'] = $identity;
    return $result;
}, 5, 3);
add_action('woocommerce_store_api_checkout_update_order_meta', function ($order) {
    $identity = $GLOBALS['lld_checkout_context'] ?? null;
    if (!$identity) return;
    $record = lld_record($identity['key']);
    $record['order'] = $order->get_id();
    lld_save($identity['key'], $record);
    // Ownership is resolved from a validated WP session, never billing email or input ID.
    $order->set_customer_id($identity['customer_id'] ?? 0);
    $order->update_meta_data('_lld_checkout_session', $identity['session']);
    $order->update_meta_data('_lld_checkout_attempt', $identity['attempt']);
});
add_action('woocommerce_rest_checkout_process_payment_with_context', function ($context) {
    $identity = $GLOBALS['lld_checkout_context'] ?? null;
    if (!$identity) return;
    $record = lld_record($identity['key']);
    // Persist before any gateway runs. Missing evidence must never make an
    // uncertain payment safe to repeat, including attempts from older bridges.
    if (!$record || empty($record['order']) || (int) $record['order'] !== (int) $context->order->get_id()) {
        throw new RuntimeException('Could not correlate payment processing with checkout.');
    }
    $record['payment_started'] = true;
    lld_save($identity['key'], $record);
}, PHP_INT_MIN);
add_filter('rest_post_dispatch', function ($response, $server, $request) {
    $identity = $GLOBALS['lld_checkout_context'] ?? null;
    if (!$identity || $request->get_route() !== '/wc/store/v1/checkout') return $response;
    unset($GLOBALS['lld_checkout_context']);
    $record = lld_record($identity['key']);
    $record['response'] = $response->get_data();
    $record['status'] = $response->get_status();
    lld_save($identity['key'], $record);
    if ($record['status'] >= 500) lld_checkout_critical_alert('checkout_processing', array('status' => $record['status']));
    $order = !empty($record['order']) ? wc_get_order($record['order']) : null;
    // Never expire a lock simply because a network response is late.
    if ((!$order && $record['status'] >= 400) || ($order && ($order->is_paid() || $order->has_status(array('failed', 'cancelled', 'checkout-draft'))))) lld_delete($identity['lock']);
    $response->header('Cache-Control', 'no-store, private');
    return $response;
}, 10, 3);
function lld_checkout_blocked_before_payment($record, $order) {
    // Woo's fraud protector throws this 403 during order_processed, before
    // the payment-context hook. Preserve its decision; never bypass the check.
    return ($record['payment_started'] ?? null) === false
        && ($record['status'] ?? 0) === 403
        && ($record['response']['code'] ?? '') === 'woocommerce_rest_checkout_error'
        && $order->has_status(array('pending', 'checkout-draft'))
        && !$order->is_paid() && !$order->get_date_paid() && !$order->get_transaction_id()
        && !$order->get_meta('_stripe_intent_id') && !$order->get_meta('_stripe_setup_intent')
        && !$order->get_meta('_stripe_checkout_session_id');
}
function lld_order_status($request) {
    $identity = lld_request_identity($request);
    $record = lld_record($identity['key']);
    if ($record && empty($record['order']) && ($record['status'] ?? 0) >= 400) return lld_response(array('number' => null, 'status' => 'failed', 'paid' => false, 'items' => array(), 'downloads' => array()));
    if (!$record || empty($record['order'])) return lld_error('No order is available for this checkout attempt yet.', 404);
    $order = wc_get_order($record['order']);
    if (!$order || $order->get_meta('_lld_checkout_session') !== $identity['session'] || $order->get_meta('_lld_checkout_attempt') !== $identity['attempt']) return lld_error('Order not available.', 404);
    $blocked = lld_checkout_blocked_before_payment($record, $order);
    // Explicitly requested after Stripe authentication. The gateway retrieves its own intent;
    // neither an arbitrary intent ID nor a client-reported payment status is accepted.
    if (!$blocked && $request->get_param('confirm') === true && lld_configuration()['enabled'] && $order->get_payment_method() === 'stripe' && $order->has_status(array('pending', 'failed'))) {
        if (null === WC()->cart) wc_load_cart();
        WC_Stripe::get_instance()->get_main_stripe_gateway()->verify_intent_after_checkout($order);
        $order = wc_get_order($record['order']);
    }
    $paid = $order->is_paid() && (bool) $order->get_date_paid();
    // Woo 11.1.2 changes a draft to pending before invoking any payment gateway.
    // A recorded 4xx rejection while it is still a draft is a pre-payment failure.
    // An unresolved draft alone is NOT proof of failure (it may still be processing).
    $rejected = !$paid && $order->has_status('checkout-draft')
        && ($record['status'] ?? 0) >= 400 && ($record['status'] ?? 0) < 500
        && !$order->get_meta('_stripe_intent_id') && !$order->get_meta('_stripe_setup_intent')
        && !$order->get_transaction_id();
    if ($paid && $order->get_payment_method() === 'stripe' && $order->get_meta('_stripe_upe_waiting_for_redirect') && class_exists('WC_Stripe_Order_Helper')) {
        // Mirror the gateway's redirect bookkeeping after its own verifier completed payment.
        $helper = WC_Stripe_Order_Helper::get_instance();
        $helper->update_stripe_upe_redirect_processed($order, true);
        $helper->delete_stripe_upe_waiting_for_redirect($order);
        $order->save();
    }
    if ($paid || $rejected || $blocked || $order->has_status(array('failed', 'cancelled', 'refunded'))) {
        $lock = lld_record($identity['lock']);
        if (($lock['attempt'] ?? '') === $identity['attempt']) lld_delete($identity['lock']);
    }
    $downloads = array();
    if ($paid && $order->is_download_permitted()) {
        foreach ($order->get_downloadable_items() as $item) {
            $remaining = $item['downloads_remaining'] ?? '';
            // Use the order permission's expiry, not today's product setting.
            $expires = $item['access_expires'] ?? null;
            if ($expires instanceof DateTimeInterface) {
                $expiry_timestamp = $expires->getTimestamp();
                $expires = $expires->format(DATE_ATOM);
            } elseif ($expires) {
                $expiry_timestamp = strtotime($expires);
                if ($expiry_timestamp === false) continue;
                $expires = gmdate(DATE_ATOM, $expiry_timestamp);
            } else {
                $expiry_timestamp = null;
                $expires = null;
            }
            if ($remaining !== '' && (int) $remaining <= 0) continue;
            if ($expiry_timestamp !== null && $expiry_timestamp < time()) continue;
            $downloads[] = array(
                'productId' => (int) $item['product_id'],
                'productName' => $item['product_name'],
                'downloadId' => $item['download_id'],
                'name' => $item['download_name'],
                'url' => $item['download_url'],
                'remaining' => $remaining,
                'expires' => $expires,
            );
        }
    }
    $items = array();
    foreach ($order->get_items() as $item) $items[] = array('id' => $item->get_variation_id() ?: $item->get_product_id(), 'name' => $item->get_name(), 'quantity' => $item->get_quantity(), 'total' => $item->get_total());
    $authentication = null;
    $redirect = $record['response']['payment_result']['redirect_url'] ?? '';
    if (!$paid && $order->has_status('pending') && preg_match('/^#wc-stripe-confirm-(pi|si):(\d+):((?:pi|seti)_[A-Za-z0-9]+_secret_[A-Za-z0-9]+):[A-Za-z0-9]+$/D', $redirect, $match) && (int)$match[2] === $order->get_id()) {
        $authentication = array('type' => $match[1], 'clientSecret' => $match[3]);
    }
    return lld_response(array('number' => $order->get_order_number(), 'status' => $blocked ? 'blocked' : ($rejected ? 'failed' : $order->get_status()), 'failureReason' => $blocked ? 'checkout_blocked' : ($rejected ? 'checkout_validation' : null), 'paid' => $paid, 'total' => $order->get_total(), 'currency' => $order->get_currency(), 'items' => $items, 'downloads' => $downloads, 'authentication' => $authentication));
}
